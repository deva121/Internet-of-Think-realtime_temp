# [Internet-of-Think](https://github.com/ulilalkhaq4/Internet-of-Think)
## Realtime Temperature Monitor

### Creator: 
* Muh Ulil Alkhaq (G.211.19.0079) <br>
* Farid Aan Yuwafiq (G.211.19.0078) <br>
* Devara Nafiska W. (G.211.19.0089) <br>

### Description: 
Update every one seconds

### Screenshot:
![preview](Screenshot%202022-12-04%20090714.jpg)
